THEY LEFT THE BAD WIRE IN THE BROOKLYN BRIDGE - video project
About 52 seconds, vertical 720x1280, Garrett narration already in this folder (voiceover.wav).

TO MAKE THE VIDEO (needs a Windows PC or a Mac - not a phone)
1. Install Node.js (LTS) from https://nodejs.org, then restart.
2. Unzip this folder.
3. Windows: double-click test_render.bat first (renders the first 3 seconds, a few minutes).
   If that works, double-click render.bat. Mac: open Terminal, drag render.sh in, press Enter.
4. Your video appears as final.mp4 in this folder.

If anything fails: double-click check.bat, wait, and send Claude the file out\check_log.txt.

NOTE: this project was built and logic-checked but NOT rendered yet (the chat sandbox had no network
for the video tools), so the first real look at the picture is your test render.

GITHUB CODESPACES (from a phone): upload the zip to a GitHub repo, open a Codespace, then run:
  unzip brooklyn-bridge-short-project.zip && cd bridge-short && bash codespace_render.sh
