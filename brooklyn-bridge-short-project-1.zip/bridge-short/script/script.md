# The Bad Wire in the Brooklyn Bridge — script

Working title: **They Left the Bad Wire in the Brooklyn Bridge** · 9:16 · about 59 s · 166 words at 170 wpm

## Shot table

| # | Start (est.) | Words | Key | Line | On screen |
|---|---|---|---|---|---|
| 1 | 0.0s | 15 | hook | In eighteen seventy-eight, engineers found bad wire inside the Brooklyn Bridge, and left it there. | Dusk, Brooklyn Bridge tower; a cable close-up with one spool tagged REJECTED |
| 2 | 5.3s | 17 | span | It was meant to be the longest bridge in the world, hanging from four giant steel cables. | Wide: unfinished span, four cables; sign 'LONGEST BRIDGE IN THE WORLD' |
| 3 | 11.3s | 16 | yousee | You see, every spool of cable wire had to pass a test before it was approved. | Wire-mill yard: inspector stamps APPROVED on spools |
| 4 | 17.0s | 17 | but | But the wire company was swapping approved spools for rejected ones on the way to the bridge. | Wagon detours to a warehouse; unnamed workers swap spools; REJECTED pile |
| 5 | 23.0s | 18 | then | Then, by the time anyone noticed, hundreds of tons of rejected wire were already woven into the cables. | Cable cross-section: red-tagged wires woven among good ones; counter 'TONS' ticks up |
| 6 | 29.3s | 17 | stuck | It could not be pulled out, and chief engineer Washington Roebling had to decide what to do. | Engineer at a drafting desk, chalkboard of sums, cables behind the window |
| 7 | 35.3s | 11 | design | You see, the bridge was designed six times stronger than needed. | Chalkboard '6x' beside a tiny truck and a huge weight scale |
| 8 | 39.2s | 15 | rope | Think of a rope made of thin threads: extra good threads cover for bad ones. | Close-up of a thick rope: a few red threads among many gold ones |
| 9 | 44.5s | 18 | so | So he added about one hundred fifty extra wires to every cable, paid for by the wire company. | Workers add wires; sign '+150' ticks up; invoice stamped 'PAID BY WIRE CO.' |
| 10 | 50.9s | 8 | opened | The bridge opened in May of eighteen eighty-three. | Morning: crowds, flags, ribbon; banner 'MAY 1883' |
| 11 | 53.7s | 14 | close | And the bad wire is still up there, holding the road over the river. | Dusk: traffic crosses; one red wire glows inside a cable, then fades |

## Voice-over

**Chapter 1 - The Hidden Problem (0:00)**

In eighteen seventy-eight, engineers found bad wire inside the Brooklyn Bridge, and left it there. It was meant to be the longest bridge in the world, hanging from four giant steel cables. You see, every spool of cable wire had to pass a test before it was approved. But the wire company was swapping approved spools for rejected ones on the way to the bridge. Then, by the time anyone noticed, hundreds of tons of rejected wire were already woven into the cables.

**Chapter 2 - The Fix (0:29)**

It could not be pulled out, and chief engineer Washington Roebling had to decide what to do. You see, the bridge was designed six times stronger than needed. Think of a rope made of thin threads: extra good threads cover for bad ones. So he added about one hundred fifty extra wires to every cable, paid for by the wire company. The bridge opened in May of eighteen eighty-three. And the bad wire is still up there, holding the road over the river.

## Rulebook check

- Hook 15 words, ends at about 5 s: OK
- 11 shots, 166 words, about 59 s at 170 wpm: OK
- But = shot 4, Then = shot 5, problem = shot 6: OK
- First "You see" at 19% (stakes), second at 60% (the science, with an everyday object): OK
- "So..." at 76%: a little earlier than the example script (80-93%) because two short closing shots follow it
- Closing line 14 words, no call to action: OK
- No invented quotes. The warehouse swap is shown with generic, unnamed workers.

## Fact map

| Claim | Sources |
|---|---|
| Defective wire found in 1878 | sheffielder.net (Sheffield steel history); Baruch College CUNY NYC infrastructure page |
| Longest bridge in the world for its time; four main cables | Wire Rope News (Don Sayenga, "The Brooklyn Bridge Experiment"); history101.nyc |
| Every spool was tested/inspected before approval | The Daily Beast (Great American Scandals); VoiceMap Brooklyn Bridge tour |
| Approved wire was swapped for rejected wire after inspection | The Daily Beast; VoiceMap |
| Hundreds of tons of rejected wire already woven into cables | techdebtpolicy.com (221 tons, citing Talbot 2011); Pipeline Media Lab (500 tons). Sources differ, so the script says "hundreds of tons" |
| Rejected wire could not be removed | techdebtpolicy.com; Today in History blog |
| Designed six times stronger than needed | Wire Rope News; Today in History blog |
| About 150 extra wires added to each cable, supplied at the wire company's expense | techdebtpolicy.com; The Daily Beast; sheffielder.net; Today in History blog |
| Bridge opened May 24, 1883 | Today in History blog; Baruch College CUNY |
| Bad wire is still in the cables today | Today in History blog; techdebtpolicy.com |

## Left out on purpose

- The supplier's name and later fate: he's a real person, and sources mix fraud, bad checks and prison time.
- The exact tonnage of bad wire (221 vs 500 tons) and the final safety margin (four vs five times stronger): sources disagree.
- The exact extra-wire count: most sources say about 150 per cable, but one says 152 and one says 250.
- "Eighty rings tested, only five passed": only two weaker sources.
- The stampede six days after opening: unrelated to the wire and distressing.
- Emily Roebling: a great story, but a different one. Good for a follow-up Short.

## Wording to watch

- "Wire company," never a named person, so no real person is cast as a villain.
- "Engineers found" is deliberate: sources split between the bridge company and Roebling's team.
- "Designed six times stronger" is passive on purpose: sources credit both John and Washington Roebling.
- Don't imply the bridge is unsafe today. It has carried traffic for over 140 years.
- Roebling is pronounced "ROH-bling".
