#!/bin/bash
# Run this inside GitHub Codespaces (Linux). One command does everything:  bash codespace_render.sh
set -e
cd "$(dirname "$0")"
echo "[1/5] Installing system libraries for the render browser..."
sudo apt-get update -y >/dev/null 2>&1 || true
sudo apt-get install -y libnss3 libatk1.0-0 libatk-bridge2.0-0 libcups2 libdrm2 libxkbcommon0 libxcomposite1 libxdamage1 libxfixes3 libxrandr2 libgbm1 libpango-1.0-0 libcairo2 >/dev/null 2>&1 || true
sudo apt-get install -y libasound2t64 >/dev/null 2>&1 || sudo apt-get install -y libasound2 >/dev/null 2>&1 || true
echo "[2/5] Installing video tools (a few minutes)..."
npm install
npm rebuild esbuild >/dev/null 2>&1 || true
mkdir -p out
echo "[3/5] 3-second test render..."
npx remotion render src/index.jsx Story out/test.mp4 --gl=swangle --concurrency=2 --frames=0-89
echo "[4/5] Full render (this is the long part - watch the frame count go up to about 1550)..."
npx remotion render src/index.jsx Story out/full_silent.mp4 --gl=swangle --concurrency=2 --image-format=jpeg --jpeg-quality=92 --crf=17
echo "[5/5] Adding the voiceover..."
npx remotion ffmpeg -y -hide_banner -loglevel error -i out/full_silent.mp4 -i voiceover.wav -map 0:v -map 1:a -c:v copy -c:a aac -b:a 192k -shortest final.mp4
echo "DONE - download final.mp4 (right-click it in the file list, then Download)."
