import * as THREE from 'three';
import {INK, rng, toon, box, cyl, sign, facade, lampPost, ground, cloud, paintTex, ink} from './kit.js';
import {character} from './char.js';
import {wordT} from './camera.js';
import {dressOffice} from './dress.js';
import * as P from './props.js';

// locations (x offsets so every set lives in the same scene)
export const LOC = {bridge: 0, office: 600, yard: 700, warehouse: 800, cable: 1000, rope: 1100};

// smooth 0..1 between a and b (seconds)
export const ease = (t, a, b) => { const x = Math.min(1, Math.max(0, (t - a) / (b - a))); return x * x * (3 - 2 * x); };
const lerp = (a, b, k) => a + (b - a) * k;

const DECK_Y = 9.4;           // walking surface of the bridge deck
const CABLE_Z = [-5.0, -3.4, 3.4, 5.0]; // the four main cables

// ---- main-cable shape (x, y) from anchorage to anchorage ----
const CPTS = [[-118, 13], [-84, 22], [-48, 37.5], [-28, 26], [-12, 18.2], [0, 15.5], [12, 18.2], [28, 26], [48, 37.5], [84, 22], [118, 13]];
const cableCurve = new THREE.CatmullRomCurve3(CPTS.map(([x, y]) => new THREE.Vector3(x, y, 0)), false, 'centripetal');
const cableSamples = cableCurve.getPoints(480);
export function cableY(x) {
  const s = cableSamples; const n = s.length;
  if (x <= s[0].x) return s[0].y; if (x >= s[n - 1].x) return s[n - 1].y;
  let lo = 0, hi = n - 1; while (hi - lo > 1) { const m = (lo + hi) >> 1; if (s[m].x <= x) lo = m; else hi = m; }
  const a = s[lo], b = s[hi]; return a.y + (b.y - a.y) * (x - a.x) / ((b.x - a.x) || 1);
}

// a thin straight rod between two points in the x/y plane
function rod(x1, y1, x2, y2, z, r, mat) {
  const dx = x2 - x1, dy = y2 - y1, L = Math.hypot(dx, dy);
  const m = new THREE.Mesh(new THREE.CylinderGeometry(r, r, L, 5), mat);
  m.position.set((x1 + x2) / 2, (y1 + y2) / 2, z); m.rotation.z = Math.atan2(-dx, dy);
  return m;
}

// ---- gothic-arched stone tower (two pointed arches the roadways pass through) ----
function stoneTower(tx) {
  const g = new THREE.Group();
  const hw = 9.5, H = 36.5;
  const shape = new THREE.Shape();
  shape.moveTo(-hw, 0); shape.lineTo(hw, 0); shape.lineTo(hw, H); shape.lineTo(-hw, H); shape.closePath();
  for (const cx of [-4.8, 4.8]) {
    const h = new THREE.Path();
    h.moveTo(cx - 3.1, 9.0); h.lineTo(cx - 3.1, 19.5);
    h.quadraticCurveTo(cx - 3.1, 24, cx, 26.5);
    h.quadraticCurveTo(cx + 3.1, 24, cx + 3.1, 19.5);
    h.lineTo(cx + 3.1, 9.0); h.closePath();
    shape.holes.push(h);
  }
  const tex = paintTex('#b8a389', {seed: 7, stains: 14, stripes: (gg, W, Hh) => { gg.strokeStyle = 'rgba(70,50,40,0.35)'; gg.lineWidth = 2; for (let i = 0; i < 8; i++) { gg.beginPath(); gg.moveTo(0, i * Hh / 8); gg.lineTo(W, i * Hh / 8); gg.stroke(); } }});
  tex.wrapS = tex.wrapT = THREE.RepeatWrapping; tex.repeat.set(0.06, 0.06);
  const m = new THREE.Mesh(new THREE.ExtrudeGeometry(shape, {depth: 8, bevelEnabled: false}), toon('#ffffff', tex));
  m.rotation.y = Math.PI / 2; m.position.set(tx - 4, 0, 0);
  ink(m, 0.1, true); g.add(m);
  g.add(box(8.8, 1.2, 19.8, '#a89577', {x: tx, y: H + 0.6, thick: 0.06}));
  g.add(box(6.2, 1.0, 17.4, '#b8a389', {x: tx, y: H + 1.7, thick: 0.06}));
  return g;
}

function boat(sail = '#f2e6cc') {
  const g = new THREE.Group();
  g.add(box(7, 1.1, 2.4, '#6b4430', {y: 0.2}));
  g.add(box(2.2, 0.9, 1.6, '#8a5a3b', {x: -1.8, y: 1.1}));
  g.add(cyl(0.07, 0.09, 8, '#3a2a20', {x: 0.8, y: 4.6}));
  g.add(box(3.4, 5.2, 0.06, sail, {x: 0.85, y: 4.9, thick: 0.01, edges: false}));
  return g;
}

// wire reel lying with its axis toward the viewer; flange radius = s
function spool({tag = null, tagBg = '#c43d32', s = 1} = {}) {
  const g = new THREE.Group();
  const drum = cyl(0.65 * s, 0.65 * s, 0.9 * s, '#8a8f98', {seg: 24}); drum.rotation.x = Math.PI / 2; g.add(drum);
  for (const z of [0.5 * s, -0.5 * s]) { const f = cyl(1.0 * s, 1.0 * s, 0.12 * s, '#7a5238', {seg: 28}); f.rotation.x = Math.PI / 2; f.position.z = z; g.add(f); }
  if (tag) {
    const t = sign(tag, 1.5 * s, 0.5 * s, {bg: tagBg, fg: '#fff4dc', w: 480, h: 160, font: 'bold 80px Arial, sans-serif'});
    t.position.set(0, -0.35 * s, 0.6 * s); g.add(t); g.userData.tag = t;
  }
  return g;
}

function lamp(x, y, z, W) {
  W.add(cyl(0.02, 0.02, 1.0, '#2b2b2e', {x, y: y + 0.6, z}));
  const b = new THREE.Mesh(new THREE.SphereGeometry(0.3, 10, 8), new THREE.MeshBasicMaterial({color: '#ffe2a6'})); b.position.set(x, y, z); W.add(b);
}

function room(ox, {w = 14, h = 5, d = 10, wall = '#efe0c4', floor = '#a7764e', seed = 4} = {}) {
  const g = new THREE.Group();
  const wt = paintTex(wall, {seed, stains: 14}); wt.repeat.set(2, 1);
  const walls = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), toon('#ffffff', wt, {side: THREE.BackSide}));
  walls.position.set(ox, h / 2, 0); walls.receiveShadow = true; g.add(walls);
  const ft = paintTex(floor, {seed: seed + 1, stripes: (gg, W, H) => { gg.strokeStyle = 'rgba(60,30,15,0.35)'; gg.lineWidth = 2; for (let i = 0; i < 10; i++) { gg.beginPath(); gg.moveTo(0, i * H / 10); gg.lineTo(W, i * H / 10); gg.stroke(); } }});
  ft.repeat.set(3, 2);
  const fl = new THREE.Mesh(new THREE.BoxGeometry(w - 0.02, 0.1, d - 0.02), toon('#ffffff', ft)); fl.position.set(ox, 0.0, 0); fl.receiveShadow = true; g.add(fl);
  g.add(box(w, 0.25, 0.15, '#6b4a36', {x: ox, y: 0.12, z: -d / 2 + 0.1, thick: 0.01}));
  return g;
}

// flat board with a live canvas texture on its front face
function liveBoard(w, h, cw, ch, frame = '#5a3a26') {
  const c = document.createElement('canvas'); c.width = cw; c.height = ch;
  const tex = new THREE.CanvasTexture(c); tex.colorSpace = THREE.SRGBColorSpace; tex.anisotropy = 8;
  const b = box(w, h, 0.12, '#ffffff', {thick: 0.02});
  b.material = [toon(frame), toon(frame), toon(frame), toon(frame), new THREE.MeshBasicMaterial({map: tex}), toon(frame)];
  return {board: b, ctx: c.getContext('2d'), tex};
}

export function buildWorld() {
  const W = new THREE.Group();
  const chars = [];
  const person = (pal, hat, x, y, z, seed, glasses = false, ry = 0) => {
    const c = character({palette: pal, hat, glasses, seed}); c.position.set(x, y, z); c.rotation.y = ry; W.add(c); chars.push(c); return c;
  };

  // ================= BRIDGE (hook, span, opened, close) =================
  const water = new THREE.Mesh(new THREE.BoxGeometry(800, 0.5, 460), toon('#5d93bf')); water.position.set(0, -0.5, -70); water.receiveShadow = true; W.add(water);
  const rw = rng(5);
  for (let i = 0; i < 130; i++) W.add(box(2 + rw() * 3, 0.05, 0.25, '#d4e9f5', {x: -150 + rw() * 300, y: -0.22, z: -30 + rw() * 90, edges: false, thick: 0.001}));
  for (const s of [-1, 1]) {
    W.add(ground(190, 220, '#9c958a', {x: s * 207, z: -40, seed: 12 + s, repeat: 14}));
    W.add(box(22, 14, 18, '#a89577', {x: s * 122, y: 7, z: 0, thick: 0.06}));
    const cols = ['#c98f6b', '#b8775e', '#d1a47a', '#a86f5c', '#c4a27c', '#9e7b66'];
    for (let i = 0; i < 6; i++) {
      const h = 10 + rw() * 9;
      const f = facade({w: 10 + rw() * 3, h, color: cols[(i + (s > 0 ? 2 : 0)) % 6], cols: 3, rows: Math.floor(h / 3.6), seed: 30 + i + s * 7, interior: '#3b2b33'});
      f.position.set(s * (146 + i * 12.5), 0, -6); W.add(f);
      W.add(box(11, h, 8, '#8f6c5e', {x: s * (146 + i * 12.5), y: h / 2, z: -10.4, thick: 0.04}));
    }
  }
  for (let i = 0; i < 18; i++) { const h = 28 + rw() * 46, w = 11 + rw() * 10; W.add(box(w, h, 10, '#b9c3c9', {x: -230 + i * 27 + rw() * 6, y: h / 2, z: -95 - rw() * 40, thick: 0.08})); }
  for (let i = 0; i < 7; i++) W.add(cloud(-90 + i * 30, 100 + (i % 3) * 10, -150, 7));

  // deck, truss, rails, lamps
  W.add(box(236, 0.8, 13, '#8a7a68', {y: 9.0, thick: 0.05}));
  W.add(box(236, 0.1, 3.0, '#a8824f', {y: DECK_Y + 0.05, edges: false, thick: 0.001}));
  for (const z of [-3.9, 3.9]) W.add(box(236, 0.06, 3.9, '#5b5560', {y: DECK_Y + 0.03, z, edges: false, thick: 0.001}));
  for (const z of [-6.4, 6.4]) {
    W.add(box(236, 1.7, 0.15, '#3b3d44', {y: 8.2, z, thick: 0.02}));
    W.add(box(236, 0.1, 0.1, '#2f2f33', {y: DECK_Y + 1.0, z, thick: 0.01, edges: false}));
    for (let x = -114; x <= 114; x += 6) W.add(box(0.1, 1.0, 0.1, '#2f2f33', {x, y: DECK_Y + 0.5, z, thick: 0.01, edges: false}));
  }
  for (let x = -108; x <= 108; x += 18) { const l = lampPost(x, 6.2, 4.2); l.position.y = DECK_Y; W.add(l); }
  W.add(stoneTower(-48), stoneTower(48));

  // cables, suspenders, diagonal stays
  const cmat = toon('#3b3d44'), smat = toon('#4a4d55');
  for (const z of CABLE_Z) {
    const tube = new THREE.Mesh(new THREE.TubeGeometry(new THREE.CatmullRomCurve3(CPTS.map(([x, y]) => new THREE.Vector3(x, y, z)), false, 'centripetal'), 220, 0.42, 8), cmat);
    ink(tube, 0.03, false); W.add(tube);
    for (let x = -112; x <= 112; x += 4.5) {
      if (Math.abs(Math.abs(x) - 48) < 4) continue;
      const top = cableY(x); if (top < DECK_Y + 1) continue;
      const hgt = top - DECK_Y;
      const m = new THREE.Mesh(new THREE.CylinderGeometry(0.05, 0.05, hgt, 5), smat); m.position.set(x, DECK_Y + hgt / 2, z); W.add(m);
    }
    for (const tx of [-48, 48]) for (const dir of [-1, 1]) for (let k = 1; k <= 6; k++) W.add(rod(tx, 36.5, tx + dir * k * 10.5, DECK_Y, z, 0.04, smat));
  }

  // signs on the bridge
  const longest = sign('LONGEST BRIDGE IN THE WORLD', 9, 2.4, {bg: '#f2e6cc', w: 900, h: 240, font: 'bold 78px Arial, sans-serif'});
  longest.position.set(-20, DECK_Y + 2.5, 6.9); W.add(longest);
  W.add(cyl(0.08, 0.1, 4, '#3a3a3a', {x: -24.2, y: DECK_Y + 2.0, z: 6.9}), cyl(0.08, 0.1, 4, '#3a3a3a', {x: -15.8, y: DECK_Y + 2.0, z: 6.9}));

  // workers on the deck + the rejected spool for the hook
  person('welder', 'cap', -30, DECK_Y, 4.8, 31);
  person('engineer', 'bowler', -37.5, DECK_Y, 2.2, 32, true);
  person('clerk', 'top', -20, DECK_Y, 0.6, 33);
  person('mustard', 'cap', -8, DECK_Y, -1.2, 34);
  person('red', 'none', 6, DECK_Y, 0.4, 35);
  person('teal', 'bowler', 18, DECK_Y, 1.6, 36);
  person('navy', 'cap', 30, DECK_Y, -0.8, 37);
  const hookSpool = spool({tag: 'REJECTED', tagBg: '#c43d32', s: 1.0}); hookSpool.position.set(-34, DECK_Y + 1.05, 3.2); W.add(hookSpool);
  const hookSpool2 = spool({s: 0.9}); hookSpool2.position.set(-36.4, DECK_Y + 0.95, 2.4); W.add(hookSpool2);

  // boats
  const boats = [];
  [[14, 6, 1], [-60, -5, 2], [28, 4, 3], [70, -6, 4], [-10, 7, 5], [50, -4, 6]].forEach(([x0, sp, i]) => {
    const g = boat(['#f2e6cc', '#e6d39a', '#cfe3f0'][i % 3]); g.position.set(x0, 0, 16 + i * 7); if (sp < 0) g.rotation.y = Math.PI; W.add(g); boats.push({g, x0, sp});
  });

  // opening day (only visible in the 'opened' shot)
  const openG = new THREE.Group(); W.add(openG);
  const banner = sign('MAY 1883', 7.5, 1.9, {bg: '#c43d32', fg: '#fff4dc', font: 'bold 100px Arial, sans-serif', w: 750, h: 190});
  banner.position.set(14, DECK_Y + 5.0, 0); openG.add(banner);
  openG.add(cyl(0.1, 0.12, 5.4, '#3a3a3a', {x: 9.8, y: DECK_Y + 2.7, z: 0}), cyl(0.1, 0.12, 5.4, '#3a3a3a', {x: 18.2, y: DECK_Y + 2.7, z: 0}));
  for (let i = 0; i < 9; i++) for (const z of [-6.2, 6.2]) { const f = P.flag(['#c43d32', '#2f6db3', '#f2f0e6'][(i + (z > 0 ? 1 : 0)) % 3]); f.position.set(2 + i * 4.6, DECK_Y, z); openG.add(f); }
  const rc = rng(99);
  for (let i = 0; i < 18; i++) {
    const c = character({palette: ['red', 'teal', 'mustard', 'clerk', 'navy', 'pink', 'student', 'engineer', 'official'][i % 9], hat: ['none', 'bowler', 'top', 'cap'][i % 4], seed: 400 + i});
    c.position.set(2 + rc() * 26, DECK_Y, -5.2 + rc() * 10.4); openG.add(c); chars.push(c);
  }

  // modern traffic (only visible in the 'close' shot)
  const trafficG = new THREE.Group(); W.add(trafficG);
  const CARCOL = ['#c43d32', '#2f6db3', '#4f8a4a', '#e6d9b8', '#7a4f73', '#3a3a3f', '#d9a441', '#9fc0d4'];
  const traffic = []; const rt = rng(61);
  for (let lane = 0; lane < 2; lane++) for (let i = 0; i < 6; i++) {
    const c = (i === 3 && lane === 1) ? P.bus() : P.car(CARCOL[Math.floor(rt() * 8)], {taxi: rt() > 0.6, lights: true, seed: i});
    c.rotation.y = lane ? Math.PI : 0; trafficG.add(c);
    traffic.push({c, x0: -100 + i * 36 + rt() * 10, sp: (lane ? -1 : 1) * (6 + rt() * 3), z: lane ? -3.9 : 3.9});
  }
  for (let i = 0; i < 5; i++) person(['red', 'teal', 'mustard', 'pink', 'navy'][i], ['none', 'cap', 'none', 'bowler', 'none'][i], -50 + i * 11, DECK_Y + 0.05, 0.2, 500 + i);

  // the rejected wire that "is still up there": a glowing thread laid along the near cable
  const threadPts = []; for (let x = -34; x <= -2; x += 2) threadPts.push(new THREE.Vector3(x, cableY(x) + 0.5, 5.0));
  const threadMat = new THREE.MeshBasicMaterial({color: '#ff3b2f', transparent: true, opacity: 0});
  const redThread = new THREE.Mesh(new THREE.TubeGeometry(new THREE.CatmullRomCurve3(threadPts), 60, 0.13, 6), threadMat); W.add(redThread);

  // ================= WIRE MILL (yousee) =================
  const Y = LOC.yard;
  W.add(ground(60, 50, '#b39a72', {x: Y, z: -5, seed: 14, repeat: 8}));
  W.add(facade({w: 22, h: 10, color: '#a86f5c', cols: 5, rows: 2, door: true, seed: 71}).translateX(Y).translateZ(-8));
  W.add(box(22, 10, 10, '#8f6c5e', {x: Y, y: 5, z: -13.2, thick: 0.04}));
  W.add(cyl(0.8, 1.0, 16, '#8a5a4b', {x: Y + 8, y: 8, z: -12}));
  const millSign = sign('WIRE WORKS', 7, 1.4, {bg: '#e6d39a', w: 700, h: 140, font: 'bold 84px Arial, sans-serif'}); millSign.position.set(Y, 6.4, -7.65); W.add(millSign);
  for (let i = 0; i < 3; i++) W.add(cloud(Y + 8 + i * 3, 17 + i * 2.5, -12, 1.2, '#cfcac2'));
  const S = 0.8;
  const s0 = spool({tag: 'APPROVED', tagBg: '#4f8a4a', s: S}); s0.position.set(Y - 3.6, 0.05 + S, 0); W.add(s0);
  const s1 = spool({tag: 'APPROVED', tagBg: '#4f8a4a', s: S}); s1.position.set(Y - 1.9, 0.05 + S, 0); W.add(s1);
  const s2 = spool({s: S}); s2.position.set(Y - 0.2, 0.05 + S, 0); W.add(s2);
  const stamp = sign('APPROVED', 1.5 * S, 0.5 * S, {bg: '#4f8a4a', fg: '#f4ead4', w: 480, h: 160, font: 'bold 76px Arial, sans-serif'}); stamp.position.set(Y - 0.2, 0.05 + S - 0.35 * S, 0.6 * S); stamp.scale.setScalar(0.001); W.add(stamp);
  for (const x of [-3.0, -1.3, 0.4]) { const sp = spool({s: S}); sp.position.set(Y + x, 0.05 + S, -2.2); W.add(sp); }
  // test rig: posts, beam, hanging weight on a rope
  W.add(box(0.3, 4.4, 0.3, '#6b4430', {x: Y + 1.3, y: 2.2, z: -1.2}), box(0.3, 4.4, 0.3, '#6b4430', {x: Y + 2.7, y: 2.2, z: -1.2}), box(1.8, 0.3, 0.3, '#6b4430', {x: Y + 2.0, y: 4.35, z: -1.2}));
  const weight = new THREE.Group(); weight.add(box(0.8, 0.8, 0.8, '#6f7a7d', {thick: 0.03}));
  const wt = sign('TEST', 0.6, 0.3, {bg: '#e6d39a', w: 300, h: 150, font: 'bold 80px Arial, sans-serif'}); wt.position.set(0, 0, 0.44); weight.add(wt);
  weight.position.set(Y + 2.0, 3.1, -1.2); W.add(weight);
  const rope = cyl(0.03, 0.03, 1, '#2b2b2e', {seg: 6, thick: 0.004}); W.add(rope);
  const insp = person('official', 'bowler', Y + 0.9, 0.05, 0.5, 71, true);
  person('welder', 'cap', Y + 4.6, 0.05, -0.6, 72);
  W.add(P.at(P.fence(16), Y - 14, 0.05, -2, Math.PI / 2), P.at(P.fence(16), Y + 14, 0.05, -2, Math.PI / 2));
  W.add(P.at(P.barrel('#2f6db3'), Y + 6.4, 0.05, -1.2), P.at(P.barrel('#c43d32'), Y - 6.6, 0.05, -1.6));
  for (let i = 0; i < 4; i++) W.add(P.at(P.tree(1.3, 740 + i), Y - 20 + i * 13, 0.05, -11));

  // ================= WAREHOUSE (but) =================
  const Wh = LOC.warehouse;
  W.add(room(Wh, {w: 22, h: 8, d: 12, wall: '#7a6252', floor: '#4e4640', seed: 21}));
  W.add(P.at(P.toolRack(1), Wh - 8, 0, -5.9), P.at(P.toolRack(2), Wh + 8, 0, -5.9));
  W.add(P.at(P.ladder(3.4), Wh - 10, 0.05, -5.2), P.at(P.barrel('#c43d32'), Wh + 9.4, 0.05, -3.6), P.at(P.barrel('#2f6db3'), Wh + 8.5, 0.05, -4.3), P.at(P.barrel('#d9a441'), Wh - 9.2, 0.05, -3.2));
  const toBridge = sign('TO THE BRIDGE', 3.8, 0.95, {bg: '#e6d39a', w: 760, h: 190, font: 'bold 78px Arial, sans-serif'}); toBridge.position.set(Wh + 3.6, 4.2, -5.9); W.add(toBridge);
  for (const x of [Wh - 5, Wh + 5]) lamp(x, 6.9, -1, W);
  const wagon = new THREE.Group();
  wagon.add(box(2.6, 0.25, 1.9, '#6b4430', {y: 1.05}));
  for (const z of [-0.95, 0.95]) wagon.add(box(2.6, 0.45, 0.08, '#7a5238', {y: 1.4, z, thick: 0.02}));
  for (const [x, z] of [[-0.9, -1.0], [0.9, -1.0], [-0.9, 1.0], [0.9, 1.0]]) { const w = cyl(0.55, 0.55, 0.14, '#3b2a20', {x, y: 0.6, z, seg: 18}); w.rotation.x = Math.PI / 2; wagon.add(w); }
  wagon.add(box(2.2, 0.1, 0.1, '#5a3a26', {x: -2.3, y: 0.7}));
  wagon.position.set(Wh - 0.1, 0, 0.2); W.add(wagon);
  const SA = 0.8;
  const spoolA = spool({tag: 'APPROVED', tagBg: '#4f8a4a', s: SA}); W.add(spoolA);
  const spoolB = spool({tag: 'REJECTED', tagBg: '#c43d32', s: SA}); W.add(spoolB);
  const pile = spool({tag: 'REJECTED', tagBg: '#c43d32', s: SA}); pile.position.set(Wh + 3.9, 0.05 + SA, -1.2); W.add(pile);
  const wk1 = person('welder', 'cap', Wh - 1.9, 0.05, 1.9, 81);
  const wk2 = person('navy', 'cap', Wh + 1.7, 0.05, 1.7, 82);

  // ================= CABLE CUTAWAY (then, so) =================
  const C = LOC.cable, CY = 1.95;
  W.add(room(C, {w: 16, h: 5.5, d: 11, wall: '#8fa6a0', floor: '#6a5a4a', seed: 41}));
  const body = cyl(2.0, 2.0, 7, '#5b5f68', {seg: 40, x: C, y: CY, z: -3.5}); body.rotation.x = Math.PI / 2; W.add(body);
  for (let i = 0; i < 5; i++) { const band = cyl(2.05, 2.05, 0.14, '#3b3d44', {seg: 40, x: C, y: CY, z: -0.9 - i * 1.2}); band.rotation.x = Math.PI / 2; W.add(band); }
  for (const z of [-1.5, -4.5]) W.add(box(0.5, 0.2, 0.5, '#6b4430', {x: C, y: 0.1, z, thick: 0.01}));
  const cc = document.createElement('canvas'); cc.width = cc.height = 512; const cx = cc.getContext('2d');
  const cableTex = new THREE.CanvasTexture(cc); cableTex.colorSpace = THREE.SRGBColorSpace;
  const disc = new THREE.Mesh(new THREE.CircleGeometry(2.46, 56), new THREE.MeshBasicMaterial({map: cableTex, transparent: true}));
  disc.position.set(C, CY, 0.03); W.add(disc);
  const DOTS = []; const rd = rng(17); const STEP = 17;
  for (let row = -16; row <= 16; row++) for (let col = -16; col <= 16; col++) { const x = 256 + col * STEP + (row & 1 ? STEP / 2 : 0), y = 256 + row * STEP * 0.866; DOTS.push({x, y, d: Math.hypot(x - 256, y - 256), r: rd(), r2: rd()}); }
  let lastCable = '';
  const drawCable = (mode, p) => {
    const key = mode + Math.round(p * 40); if (key === lastCable) return; lastCable = key;
    cx.clearRect(0, 0, 512, 512);
    cx.fillStyle = '#4b4e55'; cx.beginPath(); cx.arc(256, 256, 208, 0, 7); cx.fill();
    cx.fillStyle = '#2a2a30'; cx.beginPath(); cx.arc(256, 256, 203, 0, 7); cx.fill();
    const frac = mode === 'then' ? 0.32 * p : 0.32;
    for (const d of DOTS) {
      if (d.d <= 200) { cx.fillStyle = d.r < frac ? '#c43d32' : '#d9a441'; cx.beginPath(); cx.arc(d.x, d.y, 7, 0, 7); cx.fill(); cx.strokeStyle = '#351f22'; cx.lineWidth = 1.5; cx.stroke(); }
      else if (mode === 'so' && d.d <= 226 && d.r2 < p) { cx.fillStyle = '#6fc3ff'; cx.beginPath(); cx.arc(d.x, d.y, 7, 0, 7); cx.fill(); cx.strokeStyle = '#351f22'; cx.lineWidth = 1.5; cx.stroke(); }
    }
    cableTex.needsUpdate = true;
  };
  drawCable('then', 0);
  const counter = liveBoard(2.6, 1.3, 520, 260, '#3b3d44'); counter.board.position.set(C, 4.8, 0.1); W.add(counter.board);
  for (const dx of [-1.1, 1.1]) W.add(cyl(0.02, 0.02, 0.3, '#2b2b2e', {x: C + dx, y: 5.4, z: 0.1}));
  let lastCounter = '';
  const drawCounter = (mode, n, paid) => {
    const key = mode + n + Math.round(paid * 10); if (key === lastCounter) return; lastCounter = key;
    const g = counter.ctx; g.fillStyle = '#2f4a3a'; g.fillRect(0, 0, 520, 260); g.strokeStyle = '#d9a441'; g.lineWidth = 8; g.strokeRect(6, 6, 508, 248);
    g.textAlign = 'center'; g.textBaseline = 'middle';
    if (mode === 'then') { g.fillStyle = '#f2ead6'; g.font = 'bold 56px Arial, sans-serif'; g.fillText('HUNDREDS', 260, 90); g.fillText('OF TONS', 260, 170); }
    else {
      g.fillStyle = '#6fc3ff'; g.font = 'bold 120px Arial, sans-serif'; g.fillText('+' + n, 260, 95);
      g.fillStyle = '#f2ead6'; g.font = 'bold 40px Arial, sans-serif'; g.fillText('EXTRA WIRES', 260, 175);
      if (paid > 0) { g.save(); g.globalAlpha = paid; g.fillStyle = '#ffd66b'; g.font = 'bold 32px Arial, sans-serif'; g.fillText('PAID BY THE WIRE COMPANY', 260, 224); g.restore(); }
    }
    counter.tex.needsUpdate = true;
  };
  drawCounter('then', 0, 0);
  const redSpoolL = spool({tag: 'REJECTED', tagBg: '#c43d32', s: 0.8}); redSpoolL.position.set(C - 2.7, 0.85, 1.6); W.add(redSpoolL);
  const redSpoolR = spool({tag: 'REJECTED', tagBg: '#c43d32', s: 0.8}); redSpoolR.position.set(C + 2.9, 0.85, 1.0); W.add(redSpoolR);
  W.add(P.at(P.beamStack(4, 5), C - 6.2, 0.05, -3.4, 0.2), P.at(P.barrel('#2f6db3'), C + 6.4, 0.05, -3.2), P.at(P.barrel('#d9a441'), C + 5.6, 0.05, -4.2), P.at(P.toolbox(), C - 5.0, 0.05, 1.6, 0.3));
  W.add(P.at(P.toolRack(3), C - 7.2, 0, -5.9), P.at(P.ladder(3.4), C + 7.2, 0.05, -5.2));
  for (const x of [C - 4, C + 4]) lamp(x, 5.0, -1, W);
  person('welder', 'cap', C - 4.4, 0.05, -2.6, 91);
  person('navy', 'cap', C + 4.5, 0.05, -2.4, 92);
  const roebC = person('engineer', 'bowler', C - 2.8, 0.05, 2.4, 93, true);

  // ================= OFFICE (stuck, design) =================
  const O = LOC.office;
  W.add(room(O, {w: 16, h: 5.5, d: 11, wall: '#bfe0db', seed: 8}));
  const desk = new THREE.Group();
  desk.add(box(4.2, 0.18, 2, '#8a5a3b', {y: 1.05}));
  for (const [x, z] of [[-1.9, -0.8], [1.9, -0.8], [-1.9, 0.8], [1.9, 0.8]]) desk.add(box(0.15, 1.0, 0.15, '#6b4430', {x, y: 0.5, z}));
  desk.position.set(O - 2.5, 0, 0.5); W.add(desk);
  const bp = document.createElement('canvas'); bp.width = 512; bp.height = 340; const bg = bp.getContext('2d');
  bg.fillStyle = '#2f5d8a'; bg.fillRect(0, 0, 512, 340); bg.strokeStyle = '#e9f2fa'; bg.lineWidth = 4;
  bg.strokeRect(70, 170, 40, 100); bg.strokeRect(402, 170, 40, 100);
  bg.beginPath(); bg.moveTo(0, 240); bg.lineTo(512, 240); bg.stroke();
  bg.beginPath(); bg.moveTo(0, 230); bg.quadraticCurveTo(90, 180, 90, 150); bg.quadraticCurveTo(256, 330, 422, 150); bg.quadraticCurveTo(422, 180, 512, 230); bg.stroke();
  for (let x = 130; x < 400; x += 22) { bg.beginPath(); bg.moveTo(x, 240); bg.lineTo(x, 150 + Math.pow((x - 256) / 166, 2) * 70 + 35); bg.stroke(); }
  bg.fillStyle = '#e9f2fa'; bg.font = 'bold 26px Arial, sans-serif'; bg.textAlign = 'center'; bg.fillText('EAST RIVER BRIDGE', 256, 40);
  const bpTex = new THREE.CanvasTexture(bp); bpTex.colorSpace = THREE.SRGBColorSpace; bpTex.anisotropy = 8;
  const blueprint = new THREE.Mesh(new THREE.BoxGeometry(1.8, 0.03, 1.2), [toon('#cfe3f0'), toon('#cfe3f0'), toon('#ffffff', bpTex), toon('#cfe3f0'), toon('#cfe3f0'), toon('#cfe3f0')]);
  ink(blueprint, 0.008, true); blueprint.position.set(O - 3.0, 1.17, 0.7); blueprint.rotation.y = 0.12; W.add(blueprint);
  const deskSpool = spool({tag: 'REJECTED', tagBg: '#c43d32', s: 0.28}); deskSpool.position.set(O - 1.0, 1.14 + 0.29, 0.9); W.add(deskSpool);
  dressOffice(W, O, chars);
  person('engineer', 'none', O - 2.5, 0.05, -1.55, 61, true);   // Washington Roebling (a generic cartoon engineer)
  person('clerk', 'bowler', O - 5.4, 0.05, -2.0, 62);
  const chalk = liveBoard(4.4, 2.5, 640, 360); chalk.board.position.set(O + 3.2, 2.9, -5.35); W.add(chalk.board);
  let lastChalk = -1;
  const drawChalk = (p) => {
    if (Math.abs(p - lastChalk) < 0.02) return; lastChalk = p;
    const g = chalk.ctx; g.fillStyle = '#2f4a3a'; g.fillRect(0, 0, 640, 360); g.strokeStyle = '#8a5a3b'; g.lineWidth = 22; g.strokeRect(0, 0, 640, 360);
    g.fillStyle = '#f2ead6'; g.font = 'bold 38px Arial, sans-serif'; g.textAlign = 'center'; g.fillText('SAFETY FACTOR', 320, 74);
    const n = Math.min(6, Math.floor(p * 6.99) + (p > 0 ? 1 : 0));
    for (let i = 0; i < 6; i++) {
      const x = 62 + i * 88, y = 112;
      if (i < n) { g.fillStyle = i === 0 ? '#ffd66b' : '#6fb0e6'; g.fillRect(x, y, 72, 72); g.strokeStyle = INK; g.lineWidth = 4; g.strokeRect(x, y, 72, 72); }
      else { g.strokeStyle = 'rgba(242,234,214,0.35)'; g.lineWidth = 3; g.setLineDash([8, 8]); g.strokeRect(x, y, 72, 72); g.setLineDash([]); }
    }
    g.font = 'bold 24px Arial, sans-serif'; g.fillStyle = '#f2ead6';
    if (n >= 1) g.fillText('NEEDED', 98, 214);
    if (n >= 2) g.fillText('EXTRA', 362, 214);
    if (p > 0.85) { g.save(); g.globalAlpha = Math.min(1, (p - 0.85) / 0.15); g.font = 'bold 120px Arial, sans-serif'; g.fillStyle = '#ffd66b'; g.fillText('6x', 320, 330); g.restore(); }
    chalk.tex.needsUpdate = true;
  };
  drawChalk(0);
  const win = sign('', 2.4, 2.0, {bg: '#bfe3f5', border: true}); win.position.set(O - 5, 3.1, -5.4); W.add(win);

  // ================= ROPE (rope) =================
  const R = LOC.rope;
  W.add(room(R, {w: 16, h: 5.5, d: 11, wall: '#d9c7a8', floor: '#8a6a4e', seed: 33}));
  const table = P.desk(6.6, '#7a4f33'); table.position.set(R, 0.05, 0); W.add(table);
  W.add(P.at(P.bookshelf(4), R - 5.2, 0.05, -5.15), P.at(P.bookshelf(5), R + 5.2, 0.05, -5.15), P.at(P.deskLamp(), R + 2.8, 1.12, 0.1));
  for (const x of [R - 3, R + 3]) lamp(x, 4.45, -1, W);
  person('pink', 'none', R + 3.8, 0.05, -2.4, 95, true);
  const ropeG = new THREE.Group(); ropeG.position.set(R, 1.45, 0); W.add(ropeG);
  const goldMat = new THREE.MeshToonMaterial({color: '#d9a441'}), redMat = new THREE.MeshBasicMaterial({color: '#c43d32'}), xtraMat = toon('#ffe08a');
  const thread = (rad, a0, mat) => {
    const pts = []; for (let x = -3.2; x <= 3.2; x += 0.2) { const a = a0 + x * 2.4; pts.push(new THREE.Vector3(x, Math.cos(a) * rad, Math.sin(a) * rad)); }
    const m = new THREE.Mesh(new THREE.TubeGeometry(new THREE.CatmullRomCurve3(pts), 70, 0.075, 6), mat); m.castShadow = true; return m;
  };
  ropeG.add(thread(0, 0, goldMat));
  for (let i = 0; i < 6; i++) ropeG.add(thread(0.14, i * Math.PI / 3, goldMat));
  for (let i = 0; i < 12; i++) ropeG.add(thread(0.27, i * Math.PI / 6, [2, 7, 11].includes(i) ? redMat : goldMat));
  const extras = [];
  for (let i = 0; i < 10; i++) { const m = thread(0.4, i * Math.PI / 5 + 0.15, xtraMat); m.scale.set(1, 0.001, 0.001); ropeG.add(m); extras.push(m); }

  // ================= per-frame update =================
  const update = (t, cam, shot) => {
    for (const c of chars) c.userData.update(t, cam.position);
    boats.forEach((b) => { b.g.position.x = ((b.x0 + b.sp * t + 130) % 260 + 260) % 260 - 130; });
    // bridge variants per shot
    openG.visible = shot === 'opened';
    trafficG.visible = shot === 'close';
    if (shot === 'close') for (const q of traffic) { q.c.position.set(((q.x0 + q.sp * t + 110) % 220 + 220) % 220 - 110, DECK_Y, q.z); }
    redThread.visible = shot === 'close';
    threadMat.opacity = shot === 'close' ? ease(t, wordT('close', 2) - 0.1, wordT('close', 3) + 0.2) * (0.85 + 0.15 * Math.sin(t * 8)) * (1 - 0.8 * ease(t, wordT('close', 10), wordT('close', 13))) : 0;

    // wire mill: weight drops on "test", stamp pops on "approved"
    const wy = 3.1 - 1.5 * ease(t, wordT('yousee', 10), wordT('yousee', 10) + 0.7);
    weight.position.y = wy;
    const len = Math.max(0.05, 4.2 - (wy + 0.4)); rope.scale.y = len; rope.position.set(Y + 2.0, wy + 0.4 + len / 2, -1.2);
    stamp.scale.setScalar(Math.max(0.001, ease(t, wordT('yousee', 15), wordT('yousee', 15) + 0.35)));
    insp.userData.armR.rotation.z = (t > wordT('yousee', 14) && t < wordT('yousee', 16) + 0.3) ? 1.8 + Math.sin(t * 14) * 0.35 : 0;

    // warehouse: approved spool leaves the wagon, rejected one rolls on
    const kA = ease(t, wordT('but', 5), wordT('but', 8)), kB = ease(t, wordT('but', 9), wordT('but', 12));
    spoolA.position.set(lerp(Wh - 0.1, Wh - 2.0, kA), lerp(1.15 + SA, 0.05 + SA, kA), 0.2);
    spoolB.position.set(lerp(Wh + 2.0, Wh - 0.1, kB), lerp(0.05 + SA, 1.15 + SA, kB), 0.2);
    const swapping = t > wordT('but', 5) - 0.2 && t < wordT('but', 12);
    wk1.userData.armR.rotation.z = swapping ? 1.7 : 0; wk2.userData.armL.rotation.z = swapping ? -1.7 : 0;

    // cable cutaway
    if (shot === 'then') { drawCable('then', ease(t, wordT('then', 6), wordT('then', 14))); drawCounter('then', 0, 0); }
    else if (shot === 'so') {
      drawCable('so', ease(t, wordT('so', 7), wordT('so', 9)));
      drawCounter('so', Math.round(150 * ease(t, wordT('so', 4), wordT('so', 7))), ease(t, wordT('so', 12), wordT('so', 13)));
      roebC.userData.armR.rotation.z = (t > wordT('so', 1) && t < wordT('so', 5)) ? 1.9 : 0;
    }
    // office chalkboard: six squares and "6x" on "six"
    drawChalk(ease(t, wordT('design', 6), wordT('design', 6) + 0.9));

    // rope: extra threads grow in on "extra", the bad ones flash on "bad"
    extras.forEach((m, i) => { const k = ease(t, wordT('rope', 8) + i * 0.08, wordT('rope', 8) + 0.5 + i * 0.08); m.scale.set(1, Math.max(0.001, k), Math.max(0.001, k)); });
    const flash = shot === 'rope' ? ease(t, wordT('rope', 13) - 0.2, wordT('rope', 13) + 0.2) * (1 - ease(t, wordT('rope', 14) + 0.2, wordT('rope', 14) + 0.5)) : 0;
    redMat.color.setHSL(0.0, 0.72, 0.46 + 0.22 * flash * (0.5 + 0.5 * Math.sin(t * 24)));
  };

  return {group: W, update};
}
