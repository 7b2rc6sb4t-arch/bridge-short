# Camera plan (beat-synced, ease in/out)
| Shot | Time | Location | Move | Subjects / in-world labels |
|---|---|---|---|---|
| hook | 0.0-5.6 | Bridge, dusk | Crane up from a REJECTED-tagged spool to the stone tower | REJECTED spool tag, tower, four cables |
| span | 5.6-10.6 | Bridge, day | Sweep along the span, then high over the four cables | LONGEST BRIDGE IN THE WORLD sign, four cables |
| yousee | 10.6-15.2 | Wire mill yard | Track from the reels to the test rig, then to the inspector | Weight drops on "test", APPROVED stamp pops on "approved" |
| but | 15.2-20.3 | Warehouse | Slow push in on the wagon | Approved spool leaves the wagon on "approved", rejected spool rolls on on "rejected" |
| then | 20.3-26.6 | Cable cutaway room | Push in on the cable cross-section | Red wires fill the cable from "hundreds" to "woven"; HUNDREDS OF TONS board |
| stuck | 26.6-30.1 | Office | Push from the blueprint to the engineer | EAST RIVER BRIDGE blueprint, REJECTED spool on desk |
| design | 30.1-35.0 | Office | Continue to the chalkboard (no dip) | Six squares fill and 6x appears on "six" |
| rope | 35.0-39.5 | Workshop table | Slide along a rope of threads | Extra gold threads grow in on "extra", red threads flash on "bad" |
| so | 39.5-44.9 | Cable cutaway room | Push in on the cable | +150 counter, blue extra wires ring the cable, PAID BY THE WIRE COMPANY on "paid" |
| opened | 44.9-47.6 | Bridge, morning | Push in on the opening-day banner | MAY 1883 banner, flags, crowd |
| close | 47.6-51.7 | Bridge, dusk | Low on the deck, tilting up the cable | Modern traffic crosses; a red thread glows on the cable, then fades |
Dip to cream (0.4 s) at every location change; stuck->design is one continuous move.
